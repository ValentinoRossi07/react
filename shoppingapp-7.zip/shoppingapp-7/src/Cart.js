import React from 'react';


export const Cart = ({data}) => {
    return (
        <React.Fragment>
            <thead>
            <tr>

                <th>
                    Name
                </th>
                <th>
                    Price
                </th>
            </tr>
            </thead>
            <tbody>
            {data.map((e, index) => (

                <tr key={index}>
                    <td>
                        {e.itemname}
                    </td>
                    <td>
                        {e.price}
                    </td>
                </tr>
            ))}
            </tbody>
        </React.Fragment>
    )
}