import logo from './logo.svg';
import './App.css';
import {OnlineShopping} from "./OnlineShopping";

function App() {
    return (
        <div className="App">
            <OnlineShopping/>
        </div>
    );
}

export default App;
