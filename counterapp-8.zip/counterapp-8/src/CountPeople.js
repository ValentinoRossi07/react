import React from 'react';

class CountPeople extends React.Component {
    constructor() {
        super();
        this.state = {
            entryCount: 0,
            exitCount: 0
        }
    }

    UpdateEntry() {
        this.setState(prevState => ({entryCount: prevState.entryCount + 1}))
    }

    UpdateExit() {
        this.setState(prevState => ({exitCount: prevState.exitCount + 1}))
    }

    render() {
        return (
            
                <div className="countPeople">

                    <div>
                        <button onClick={() => this.UpdateEntry()}>Login</button>
                        {this.state.entryCount} People Entered!!
                    </div>

                    <div>
                        <button onClick={() => this.UpdateExit()}>Exit</button>
                        {this.state.exitCount} People left!!
                    </div>
                </div>

            
        )
    }

}

export default CountPeople;