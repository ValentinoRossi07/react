import logo from './logo.svg';
import './App.css';
import CountPeople from "./CountPeople";

function App() {
    return (
        <div className="App">
            <CountPeople/>
        </div>
    );
}

export default App;
