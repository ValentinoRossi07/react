import React from "react";
import {ListOfPlayers} from "./ListOfPlayers";
import {IndianPlayers} from "./IndianPlayers";


class Player {
    constructor(name, score) {
        this.name = name;
        this.score = score;
    }
}


function App() {

    const [flag, setFlag] = React.useState(true)

    const players = [
        new Player('jack', 50),
        new Player('michael', 70),
        new Player('john', 40),
        new Player('Hardik', 91),
        new Player('Pant', 64),
        new Player('Jaddu', 48),
        new Player('Bhuvi', 54),
        new Player('Chahal', 64),
        new Player('Bumrah', 75),
        new Player('Shami', 80),
        new Player('pritam', 90),
    ]


    const T20Players = ['First Player', 'Second Player', 'Third Player'];
    const RanjiPlayer = ['Fourth Player', 'Fifth Player', 'Sixth Player']

    const IndianPlayer = [...T20Players, ...RanjiPlayer];

    return (
        <div className="App">
            <input type="checkbox" value={flag} onChange={() => setFlag(!flag)}/>
            {flag ?
                <ListOfPlayers players={players}/> :
                <IndianPlayers players={IndianPlayer}/>}
        </div>
    );
}

export default App;
