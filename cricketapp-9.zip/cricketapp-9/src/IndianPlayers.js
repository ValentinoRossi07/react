import React from "react";

const EvenPlayers = ([second, , four, , six]) => {
    return (
        <div>
            <li>Second : {second}</li>
            <li>Four : {four}</li>
            <li>Six : {six}</li>
        </div>
    )
}
const OddPlayers = ([first, , third, , fifth]) => {
    return (
        <div>
            <li>First : {first}</li>
            <li>Third : {third}</li>
            <li>Fifth : {fifth}</li>
        </div>
    )
}


export const IndianPlayers = ({players}) => {

    return (
        <React.Fragment>
            <div>
                <h1>
                    Indian team
                </h1>
                <h2>Odd players</h2>
                <ul>
                    {OddPlayers(players)}
                </ul>
                <hr/>
                <h2>Even Players</h2>
                <ul>
                    {EvenPlayers(players)}
                </ul>
                <hr/>
                <h2>List of Indian</h2>
                
                
                <ul>
                    {players.map((e, index) => (
                        <li key={index}>Mr. {e}</li>
                    ))}
                </ul>

            </div>
        </React.Fragment>
    )

}