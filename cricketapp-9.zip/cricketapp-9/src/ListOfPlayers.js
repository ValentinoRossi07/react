import React from "react";


export const ListOfPlayers = ({players}) => {


    const PlayersList = () => {
        return (
            <React.Fragment>
                {players.map((e, index) => (
                    <li key={index}>Ms. {e.name} <span>{e.score}</span></li>
                ))}
            </React.Fragment>
        )
    }

    const PlayerUnder70 = () => {
        return (
            <div>
                {players.map((e, index) => {

                    if (e.score <= 70) {
                        return (
                            <li key={index}>Mr. {e.name} <span>{e.score}</span></li>
                        )
                    }
                })}
            </div>
        )
    }

    return (
        <div>
            <div>
                <h1>
                    List of Players
                </h1>
                <ul>
                    <PlayersList/>
                </ul>
            </div>
            <hr/>
            <div>
                <h1>
                    List of Players less than 70
                </h1>
                <ul>
                    <PlayerUnder70/>
                </ul>
            </div>

        </div>
    )

}