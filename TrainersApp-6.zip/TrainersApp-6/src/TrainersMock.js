import Trainer from "./Trainer";

export const trainersMock = [
    new Trainer(1,
        'Priyavandana',
        'priyavandana@cognizant.com',
        '9934193558',
        '.NET',
        ['c#', 'sql server', 'react', '.NET']),
    new Trainer(2,
        'priya',
        'Priya@cognizant.com',
        '9934193678',
        '.Java',
        ['Java', 'Sql Server', 'React', 'Spring']),
    new Trainer(3,
        'Vandana',
        'vandana@cognizant.com',
        '9934193783',
        '.Python',
        ['Python','Django','angular'])    
]