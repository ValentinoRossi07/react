import React from "react";
import {Link} from "react-router-dom";
import {trainersMock} from "./TrainersMock";

export const TrainersList = () => {

    return (
        <React.Fragment>
            <div>
                <h3>Trainee List</h3>
                <ul>
                    {trainersMock.map((e, index) => (
                        <li key={index}>
                            <Link to={`/trainerlist/${e.trainerid}`}>{e.name}</Link>
                        </li>
                    ))}
                </ul>
            </div>
        </React.Fragment>
    );
};
