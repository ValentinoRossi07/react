import React from "react";
import {TrainersList} from "./TrainersList";
import {trainersMock} from "./TrainersMock";
import {Link} from "react-router-dom";

export const Home = () => {
    return (
        <React.Fragment>

            <h1>Welcome to My Academy trainers page</h1>

        </React.Fragment>
    );
};
