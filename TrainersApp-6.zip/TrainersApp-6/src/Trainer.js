class Trainer {
   constructor(trainerId, name, email, phone, technology, skill) {
      this.trainerid = trainerId;
      this.name = name;
      this.email = email;
      this.phone = phone;
      this.technology = technology;
      this.skill = skill;
   }
}

export default Trainer;
