import React from "react";
import {BrowserRouter as Router, Link, Route, Routes} from "react-router-dom";
import {Home} from "./Home";
import {TrainerDetail} from "./TrainerDetail";
import {TrainersList} from "./TrainersList";

function App() {
    return (
        <React.Fragment>
            <div className="App">
                <h1>My Academy Trainers App</h1>
                <div>
                    <Link to="/">Home</Link> | <Link to="/trainerlist">Show trainers</Link>
                </div>
                <Routes>
                    <Route exact path="/" element={<Home/>}/>
                    <Route exact path="/trainerlist" element={<TrainersList/>}/>
                    <Route
                        exact
                        path="/trainerlist/:id"
                        element={<TrainerDetail/>}
                    />
                </Routes>

            </div>
        </React.Fragment>
    );
}

export default App;
