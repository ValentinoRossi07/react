import React from "react";
import {useParams} from "react-router-dom";
import {trainersMock} from "./TrainersMock";

export const TrainerDetail = () => {
    const {id} = useParams();

    const [trainer, setTrainer] = React.useState(null);

    const filterdata = (id) => {
        return trainersMock.filter((data) => data.trainerid === Number(id));
    };

    React.useEffect(() => {
        setTimeout(() => {
            const data = filterdata(id);
            setTrainer(data[0]);
        }, 2000);
    }, []);

    return (
        <React.Fragment>
            <h1>Trainer Details</h1>
            {trainer === null ? (
                <p>Loading..</p>
            ) : (
                <div>
                    <h4>
                        {trainer.name} {trainer.technology}
                    </h4>
                    <p>{trainer.email}</p>
                    <p>{trainer.phone}</p>
                    <ul>
                        {trainer.skill.map((data, index) => (
                            <li key={index}>{data}</li>
                        ))}
                    </ul>
                </div>
            )}
        </React.Fragment>
    );
};
